from flask import Flask, render_template, request
import joblib

app = Flask(__name__)

# Load trained model
model = joblib.load("model/crop_model.pkl")

# Crop images
crop_images = {
    "rice": "rice.jpg",
    "maize": "maize.jpg",
    "cotton": "cotton.jpg",
    "wheat": "wheat.jpg",
    "coffee":"coffee.jpg",
    "Watermelon":"Watermelon.jpg",
    "Muskmelon":"Muskmelon.jpg",
    "Chickpeas":"chickpeas.jpg",
}

# Home Page
MODEL_ACCURACY = "99.32%"

@app.route('/')
def home():
    return render_template(
        'index.html',
        accuracy=MODEL_ACCURACY
    )

# Prediction Page
@app.route('/predict', methods=['POST'])
def predict():

    data = [
        float(request.form['N']),
        float(request.form['P']),
        float(request.form['K']),
        float(request.form['temperature']),
        float(request.form['humidity']),
        float(request.form['ph']),
        float(request.form['rainfall'])
    ]

    result = model.predict([data])[0]

    image = crop_images.get(result.lower(), "rice.jpg")

    return render_template(
        'result.html',
        crop=result,
        image=image
    )

# Dashboard Page
@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

if __name__ == "__main__":
    app.run(debug=True)
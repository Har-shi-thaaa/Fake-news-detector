import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("dataset/Crop_recommendation.csv")

plt.figure(figsize=(10,8))

sns.heatmap(
    df.drop("label", axis=1).corr(),
    annot=True,
    cmap="YlGnBu"
)

plt.title("Feature Correlation Heatmap")

plt.tight_layout()

plt.savefig("static/heatmap.png")

print("Heatmap Saved Successfully")